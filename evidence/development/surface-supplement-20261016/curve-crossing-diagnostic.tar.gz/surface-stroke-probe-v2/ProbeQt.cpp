#include <QGuiApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QPainterPath>
#include <QPainterPathStroker>
#include <QDir>
static QPainterPath path(QJsonArray rows) {
    QPainterPath p;p.setFillRule(Qt::WindingFill);
    for(const auto &v:rows){const auto r=v.toObject();const auto pts=r["points"].toArray();auto point=[&](int i){const auto a=pts[i].toArray();return QPointF(a[0].toDouble(),a[1].toDouble());};
        const auto k=r["kind"].toString();if(k=="move")p.moveTo(point(0));else if(k=="line")p.lineTo(point(0));else if(k=="cubic")p.cubicTo(point(0),point(1),point(2));else if(k=="quad")p.quadTo(point(0),point(1));else p.closeSubpath();}
    return p;
}

#include <algorithm>
#include <array>
#include <cmath>
#include <vector>
static QPointF at(const std::array<QPointF,4> &p,double t) {
    auto q=p;for(int n=3;n>0;--n)for(int i=0;i<n;++i)q[i]=q[i]*(1-t)+q[i+1]*t;return q[0];
}
static bool exactContains(const QPainterPath &path,const QPointF &query) {
    int winding=0;QPointF previous,first;bool open=false;
    auto line=[&](QPointF a,QPointF b){
        if(a.y()==b.y() ||query.y()<std::min(a.y(),b.y()) ||query.y()>=std::max(a.y(),b.y()))return;
        const double x=a.x()+(query.y()-a.y())*(b.x()-a.x())/(b.y()-a.y());
        if(query.x()<x)winding+=b.y()>a.y() ? 1:-1;
    };
    auto curve=[&](std::array<QPointF,4> p){
        const double a=-p[0].y()+3*p[1].y()-3*p[2].y()+p[3].y();
        const double b=2*(p[0].y()-2*p[1].y()+p[2].y());
        const double c=p[1].y()-p[0].y();
        std::vector<double> cuts{0,1};
        auto cut=[&](double t){if(t>0 &&t<1)cuts.push_back(t);};
        if(a==0){if(b!=0)cut(-c/b);}else {const double disc=b*b-4*a*c;if(disc>=0){const double root=std::sqrt(disc);cut((-b-root)/(2*a));cut((-b+root)/(2*a));}}
        std::sort(cuts.begin(),cuts.end());
        for(size_t i=1;i<cuts.size();++i){double lo=cuts[i-1],hi=cuts[i];const auto left=at(p,lo),right=at(p,hi);
            if(left.y()==right.y() ||query.y()<std::min(left.y(),right.y()) ||query.y()>=std::max(left.y(),right.y()))continue;
            double x;if(query.y()==left.y())x=left.x();else if(query.y()==right.y())x=right.x();else {
                const bool ascending=right.y()>left.y();
                for(;;){const double middle=(lo+hi)/2;if(middle==lo ||middle==hi)break;const auto v=at(p,middle);if((v.y()<query.y())==ascending)lo=middle;else hi=middle;}
                x=at(p,(lo+hi)/2).x();
            }
            if(query.x()<x)winding+=right.y()>left.y() ? 1:-1;
        }
    };
    for(int i=0;i<path.elementCount();++i){const auto e=path.elementAt(i);const QPointF point(e.x,e.y);
        if(e.type==QPainterPath::MoveToElement){if(open)line(previous,first);first=previous=point;open=true;}
        else if(e.type==QPainterPath::LineToElement){line(previous,point);previous=point;}
        else if(e.type==QPainterPath::CurveToElement){const auto e2=path.elementAt(++i),e3=path.elementAt(++i);const QPointF p2(e2.x,e2.y),p3(e3.x,e3.y);curve({previous,point,p2,p3});previous=p3;}
    }
    if(open)line(previous,first);return winding!=0;
}

int main(int argc,char **argv) {
    QGuiApplication app(argc,argv);QFile input("/diag/paths.json");input.open(QIODevice::ReadOnly);
    const auto data=QJsonDocument::fromJson(input.readAll()).object();QFile qt("/diag/qt-centerlines.json");qt.open(QIODevice::ReadOnly);const auto qrows=QJsonDocument::fromJson(qt.readAll()).array();
    QJsonArray results;
    for(const auto &v:data["rows"].toArray()) {
        const auto r=v.toObject();const auto center=path(r["centerline"].toArray()),nativeStroke=path(r["stroke"].toArray());
        QPainterPath qcenter;for(const auto &q:qrows)if(q.toObject()["fixture"]==r["fixture"])qcenter=path(q.toObject()["centerline"].toArray());
        QJsonArray outputs;
        for(int mode=0;mode<5;++mode) {
            QPainterPathStroker s;s.setWidth(1);s.setJoinStyle(mode==1 ? Qt::BevelJoin:Qt::MiterJoin);
            if(mode==4)s.setCurveThreshold(.001);
            const auto region=mode==0 ? nativeStroke:s.createStroke(mode==2 ||mode==4 ? qcenter:center);
            QJsonArray differences;
            for(const auto &query:r["queries"].toArray()) {
                const auto q=query.toObject();const QPointF point(q["x"].toDouble(),q["y"].toDouble());
                const bool hit=point.x()>=0 &&point.y()>=0 &&point.x()<r["width"].toDouble() &&point.y()<r["height"].toDouble() &&exactContains(region,point);
                if(hit!=q["swiftUIContains"].toBool())differences.append(QJsonObject{{"point",QJsonArray{point.x(),point.y()}},{"qt",hit},{"swiftUI",q["swiftUIContains"]}});
            }
            outputs.append(QJsonObject{{"mode",mode},{"differences",differences}});
        }
        results.append(QJsonObject{{"fixture",r["fixture"]},{"methods",outputs}});
    }
    QFile output("/diag/qt-results.json");output.open(QIODevice::WriteOnly);output.write(QJsonDocument(results).toJson());
}
