#include "surfaceborderinput.h"
#include <QMouseEvent>
#include <QPainterPathStroker>
#include <QtQuick/private/qquickpath_p.h>
#include <cmath>

SurfaceBorderInput::SurfaceBorderInput(QQuickItem *parent):QQuickItem(parent) {
    setAcceptedMouseButtons(Qt::LeftButton);
}
void SurfaceBorderInput::setOutline(QObject *outline) {
    if(m_outline==outline)return;
    auto *path=qobject_cast<QQuickPath*>(outline);
    if(outline &&!path)qFatal("Surface border input requires a Qt Quick path");
    disconnect(m_changed);disconnect(m_destroyed);m_outline=outline;
    if(path) {
        m_changed=connect(path,&QQuickPath::changed,this,&SurfaceBorderInput::refresh);
        m_destroyed=connect(path,&QObject::destroyed,this,[this]{m_outline=nullptr;m_region={};emit outlineChanged();});
    }
    refresh();emit outlineChanged();
}
void SurfaceBorderInput::setStrokeWidth(qreal width) {
    if(!std::isfinite(width)||width<0)qFatal("Surface border input width must be finite and nonnegative");
    if(width==m_width)return;
    m_width=width;refresh();emit strokeWidthChanged();
}
void SurfaceBorderInput::refresh() {
    m_region={};
    if(!m_outline ||m_width==0)return;
    QPainterPathStroker stroker;stroker.setWidth(m_width);
    m_region=stroker.createStroke(qobject_cast<QQuickPath*>(m_outline)->path());
}
bool SurfaceBorderInput::contains(const QPointF &point) const {
    if(point.x()<0 ||point.y()<0 ||point.x()>=width() ||point.y()>=height())return false;
    return m_region.contains(point);
}
void SurfaceBorderInput::mousePressEvent(QMouseEvent *event) {event->accept();}
void SurfaceBorderInput::mouseReleaseEvent(QMouseEvent *event) {event->accept();}
