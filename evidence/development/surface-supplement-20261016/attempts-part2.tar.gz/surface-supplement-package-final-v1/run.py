from pathlib import Path
import subprocess,json,time
p=Path('/package');rows=[]
commands=[(['bash','check-installed.sh'],0),(['python3','capture-surface-supplement.py','consumer-build/InstalledConsumer','captures'],0),
 (['consumer-build/InstalledConsumer','--surface-baseline'],1),(['consumer-build/InstalledConsumer','--surface-input'],1)]
for i,(c,expected) in enumerate(commands):
 start=time.monotonic()
 with (p/f'{i}.log').open('w') as log:r=subprocess.run(c,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(command=c,expectedExitCode=expected,exitCode=r.returncode,seconds=time.monotonic()-start,log=f'{i}.log'))
 (p/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(i,r.returncode,flush=True)
 if r.returncode!=expected:raise SystemExit(1)
