import QtQuick
import QtTest
import Avelino

Item {
    id:root;width:640;height:400
    Component {
        id:flatFactory
        BleeckerSurfaceModifier {
            width:640;height:400
            property alias first:a
            property alias second:b
            Rectangle {id:a;width:56;height:16;color:"red"}
            Rectangle {id:b;width:72;height:44;color:"blue"}
        }
    }
    Component {
        id:stackFactory
        BleeckerSurfaceModifier {
            width:640;height:400
            property alias stack:row
            ProposalRow {
                id:row;spacing:5
                Rectangle {width:56;height:16;color:"red"}
                Rectangle {width:72;height:44;color:"blue"}
            }
        }
    }
    Component {
        id:parentFactory
        ProposalRow {
            width:640;height:100;spacing:11
            property alias modifier:surface
            Rectangle {width:40;height:12}
            BleeckerSurfaceModifier {
                id:surface
                Rectangle {width:56;height:16}
                Rectangle {width:72;height:44}
            }
            Rectangle {width:30;height:20}
        }
    }
    Component {
        id:fontFactory
        BleeckerSurfaceModifier {
            width:640;height:400
            property alias scope:fontScope
            property alias label:label
            BleeckerFont {
                id:fontScope;family:"primary";size:32
                palette.windowText:"red"
                BleeckerText {id:label;text:"Caller"}
            }
        }
    }
    Component {
        id:buttonFactory
        BleeckerSurfaceModifier {
            width:300;height:100
            property alias caller:button
            BleeckerButton {
                id:button;text:"Caller "+localValue
                property int localValue:0
                onClicked:localValue++
            }
        }
    }
    Component {
        id:dynamicFactory
        BleeckerSurfaceModifier {
            width:640;height:400
            property alias model:repeater.model
            property alias scope:scope
            Item {
                id:scope;BleeckerLayout.flattenChildren:true
                Repeater {
                    id:repeater;model:2
                    Rectangle {width:40+index;height:20}
                }
            }
        }
    }
    TestCase {
        name:"SurfaceModifier";when:windowShown
        function init(){BleeckerTheme.dark=false;BleeckerTheme.textScale=1;BleeckerTheme.reducedMotion=true}
        function cleanup(){BleeckerTheme.dark=false;BleeckerTheme.textScale=1}
        function rect(item){const p=item.mapToItem(root,0,0);return [p.x,p.y,item.width,item.height]}
        function test_flat_leaves_keep_independent_native_frames(){
            const m=createTemporaryObject(flatFactory,root)
            tryCompare(m,"partCount",2);verify(waitForRendering(m))
            compare(rect(m.partAt(0)),[292,192,56,16]);compare(rect(m.partAt(1)),[284,178,72,44])
            compare(rect(m.first),rect(m.partAt(0)));compare(rect(m.second),rect(m.partAt(1)))
            const a=m.partAt(0),b=m.partAt(1),caller=m.first
            for(const radius of [-12,0,0.5,12,48,200]){
                m.radius=radius;BleeckerTheme.dark=!BleeckerTheme.dark;BleeckerTheme.textScale=1.5
                verify(waitForRendering(m));compare(m.partAt(0),a);compare(m.partAt(1),b);compare(m.first,caller)
                compare(rect(a),[292,192,56,16]);compare(rect(b),[284,178,72,44])
            }
        }
        function test_explicit_stack_is_one_caller(){
            const m=createTemporaryObject(stackFactory,root)
            tryCompare(m,"partCount",1);verify(waitForRendering(m))
            compare(m.partAt(0).callerItem,m.stack);compare(rect(m.partAt(0)),[253.5,178,133,44])
        }
        function test_parent_row_receives_flat_parts(){
            const row=createTemporaryObject(parentFactory,root),m=row.modifier
            tryCompare(m,"partCount",2);verify(waitForRendering(row))
            compare(row.implicitWidth,231);compare(m.partAt(0).x,51);compare(m.partAt(1).x,118)
            compare(m.partAt(0).y,42);compare(m.partAt(1).y,28)
        }
        function test_font_scope_and_baseline_are_preserved(){
            const m=createTemporaryObject(fontFactory,root)
            tryCompare(m,"partCount",1);verify(waitForRendering(m))
            const caller=m.label,part=m.partAt(0),height=caller.implicitHeight,baseline=caller.baselineOffset
            compare(part.parent,m.scope.contentItem);compare(part.callerItem,caller)
            compare(caller.font.family,BleeckerFonts.primary);compare(caller.font.pixelSize,32)
            compare(caller.color.toString(),"#ff0000");verify(part.containsTextBaseline)
            compare(part.baselineOffset,baseline);compare(part.height,height)
            m.radius=0;verify(waitForRendering(m));compare(m.label,caller);compare(caller.font.pixelSize,32)
        }
        function test_input_focus_state_and_accessibility_survive_updates(){
            const m=createTemporaryObject(buttonFactory,root)
            tryCompare(m,"partCount",1);verify(waitForRendering(m))
            const caller=m.caller,input=caller.inputItem,part=m.partAt(0)
            mouseClick(caller,caller.width/2,caller.height/2);compare(caller.localValue,1)
            input.forceActiveFocus();keyClick(Qt.Key_Space);compare(caller.localValue,2)
            for(const radius of [0,48,12]){
                m.radius=radius;BleeckerTheme.dark=!BleeckerTheme.dark;verify(waitForRendering(m))
                compare(m.caller,caller);compare(m.partAt(0),part);compare(caller.localValue,2)
                verify(input.activeFocus);compare(fixtureSetup.accessibleName(input),"Caller 2")
            }
            keyClick(Qt.Key_Space);compare(caller.localValue,3)
        }
        function test_dynamic_flat_scopes_and_repeater_removal(){
            const m=createTemporaryObject(dynamicFactory,root)
            tryCompare(m,"partCount",2);verify(waitForRendering(m))
            m.model=3;tryCompare(m,"partCount",3);verify(waitForRendering(m))
            m.model=0;tryCompare(m,"partCount",0)
            m.model=1;tryCompare(m,"partCount",1)
            m.scope.BleeckerLayout.flattenChildren=false;tryCompare(m,"partCount",1)
            tryVerify(function(){return m.partAt(0).callerItem===m.scope})
            m.scope.BleeckerLayout.flattenChildren=true;tryCompare(m,"partCount",1)
            tryVerify(function(){return m.partAt(0).callerItem!==m.scope})
        }
        function test_hidden_empty_and_zero_callers(){
            const m=createTemporaryObject(flatFactory,root)
            tryCompare(m,"partCount",2);m.first.visible=false;verify(waitForRendering(m))
            compare(m.partAt(0).width,56);compare(m.partAt(0).height,16)
            m.first.width=0;m.first.height=0;tryCompare(m.partAt(0),"width",0);tryCompare(m.partAt(0),"height",0)
            m.first.BleeckerLayout.participates=false;tryCompare(m,"partCount",1)
            m.second.BleeckerLayout.participates=false;tryCompare(m,"partCount",0)
        }
    }
}
