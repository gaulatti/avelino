#include "surfacedecorator.h"
#include "proposalrow.h"
#include <QtQml/qqml.h>
#include <QSet>
#include <functional>

void SurfaceDecorator::setTarget(QQuickItem *item) {
    if(m_target==item)return;
    disconnectObservers();
    while(!m_parts.isEmpty())removePart(m_parts.size()-1);
    m_target=item;emit configurationChanged();schedule();
}
void SurfaceDecorator::setDelegate(QQmlComponent *component) {
    if(m_delegate==component)return;
    m_delegate=component;emit configurationChanged();schedule();
}
void SurfaceDecorator::componentComplete() {
    m_complete=true;
    if(!m_target||!m_delegate)qFatal("Surface decoration requires a target and part component");
    rebuild();
}
void SurfaceDecorator::disconnectObservers() {
    for(const auto &connection:m_connections)disconnect(connection);
    m_connections.clear();
}
void SurfaceDecorator::schedule() {
    if(!m_complete||m_rebuilding||m_queued)return;
    m_queued=true;
    QMetaObject::invokeMethod(this,[this]{m_queued=false;rebuild();},Qt::QueuedConnection);
}
void SurfaceDecorator::removePart(int index) {
    const auto part=m_parts.takeAt(index);
    if(part.caller && part.caller->parentItem()==part.host) {
        part.caller->setParentItem(part.originalParent);
        if(part.wrapper && part.wrapper->parentItem()==part.originalParent)
            part.caller->stackBefore(part.wrapper);
    }
    delete part.wrapper;
}
void SurfaceDecorator::rebuild() {
    if(m_rebuilding||!m_target||!m_delegate)return;
    m_rebuilding=true;disconnectObservers();
    for(int i=m_parts.size()-1;i>=0;--i) {
        const auto &part=m_parts[i];
        if(!part.caller||!part.originalParent||!part.wrapper||!part.host
            ||part.caller->parentItem()!=part.host
            ||part.wrapper->parentItem()!=part.originalParent)removePart(i);
    }
    QList<QPointer<QQuickItem>> leaves;
    QSet<QQuickItem*> observed;
    auto observe=[&](QQuickItem *item) {
        if(observed.contains(item))return;
        observed.insert(item);
        m_connections.append(connect(item,&QQuickItem::childrenChanged,this,&SurfaceDecorator::schedule));
        m_connections.append(connect(item,&QQuickItem::parentChanged,this,&SurfaceDecorator::schedule));
        m_connections.append(connect(item,&QObject::destroyed,this,&SurfaceDecorator::schedule));
        auto hint=qobject_cast<BleeckerLayout*>(qmlAttachedPropertiesObject<BleeckerLayout>(item,true));
        m_connections.append(connect(hint,&BleeckerLayout::structureChanged,this,&SurfaceDecorator::schedule));
    };
    std::function<void(QQuickItem*)> append=[&](QQuickItem *item) {
        // An owned wrapper stands for its caller, never for its paint tree.
        for(const auto &part:m_parts)if(part.wrapper==item){append(part.caller);return;}
        if(item->inherits("QQuickRepeater"))return;
        observe(item);
        auto hint=qobject_cast<BleeckerLayout*>(qmlAttachedPropertiesObject<BleeckerLayout>(item,true));
        if(!hint->participates)return;
        if(hint->flattenChildren)for(auto nested:item->childItems())append(nested);
        else leaves.append(item);
    };
    observe(m_target);
    for(auto item:m_target->childItems())append(item);
    for(int i=m_parts.size()-1;i>=0;--i)
        if(!leaves.contains(m_parts[i].caller))removePart(i);
    for(const auto &caller:leaves) {
        if(!caller)continue;
        bool decorated=false;
        for(const auto &part:m_parts)if(part.caller==caller){decorated=true;break;}
        if(decorated)continue;
        auto originalParent=caller->parentItem();
        auto object=m_delegate->createWithInitialProperties({{"callerItem",QVariant::fromValue(caller.data())}},m_delegate->creationContext());
        auto wrapper=qobject_cast<QQuickItem*>(object);
        if(!wrapper)qFatal("Surface part creation failed: %s",qPrintable(m_delegate->errorString()));
        auto host=qvariant_cast<QQuickItem*>(wrapper->property("contentHost"));
        if(!host)qFatal("Surface part must expose its content host");
        wrapper->setParent(this);
        wrapper->setParentItem(originalParent);
        wrapper->stackBefore(caller);
        caller->setParentItem(host);
        m_parts.append({caller,originalParent,wrapper,host});
    }
    m_rebuilding=false;
}
