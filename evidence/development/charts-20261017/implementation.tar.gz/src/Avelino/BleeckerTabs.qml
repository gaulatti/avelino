import QtQuick

BleeckerSegmentedControl {}
