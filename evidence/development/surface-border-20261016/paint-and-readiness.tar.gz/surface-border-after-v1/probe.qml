import QtQuick
import Avelino
Window {
    width:240;height:120;visible:true;color:"white"
    Component.onCompleted:{BleeckerTheme.dark=false;BleeckerTheme.reducedMotion=true}
    Item {
        id:canvas;anchors.fill:parent
        Rectangle {anchors.fill:parent;color:"white"}
        BleeckerSurface {
            x:30;y:30;width:80;height:60;radius:0
            Rectangle {anchors.fill:parent;color:"red"}
        }
        BleeckerSurface {x:130;y:30;width:80;height:60;radius:0}
    }
    Timer {
        interval:1000;running:true
        onTriggered:canvas.grabToImage(function(result){
            if(!result.saveToFile("/probe/border.png"))throw new Error("Could not save border probe")
            Qt.quit()
        })
    }
}
