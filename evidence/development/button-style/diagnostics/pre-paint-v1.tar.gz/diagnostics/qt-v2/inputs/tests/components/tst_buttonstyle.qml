import QtQuick
import QtQuick.Templates as T
import QtTest
import Avelino

Item {
    id:root;width:1000;height:700
    Component {id:emptyFactory;BleeckerButtonStyle {}}
    Component {
        id:fixedFactory
        BleeckerButtonStyle {
            id:style;x:200;y:100
            onClicked:labels[0].value++
            Rectangle {objectName:"callerLabel";implicitWidth:200;implicitHeight:80;color:"red";property int value:0}
        }
    }
    Component {id:zeroFactory;BleeckerButtonStyle {x:200;y:100;Item {}}}
    Component {
        id:fontFactory
        BleeckerButtonStyle {
            x:200;y:100
            T.Label {objectName:"callerLabel";text:"Review";color:palette.windowText}
        }
    }
    Component {
        id:ownFontFactory
        BleeckerButtonStyle {
            T.Label {
                objectName:"callerLabel";text:"Review";font.family:"Libre Franklin"
                font.pointSize:BleeckerFonts.pointSizeForPixels(13);font.weight:Font.Bold;color:"red"
            }
        }
    }
    Component {
        id:rowFactory
        Item {
            id:owner;x:100;y:100;width:640;height:400
            property int calls:0
            property alias style:style
            property alias row:row
            ProposalRow {
                id:row;spacing:11
                Rectangle {implicitWidth:40;implicitHeight:12;color:"green"}
                BleeckerButtonStyle {
                    id:style;onClicked:owner.calls++
                    Rectangle {implicitWidth:92.5;implicitHeight:27;color:"red";property string text:"First child"}
                    Rectangle {implicitWidth:72;implicitHeight:44;color:"blue"}
                }
                Rectangle {implicitWidth:30;implicitHeight:20;color:"orange"}
            }
        }
    }
    TestCase {
        name:"ButtonStyle";when:windowShown
        function init(){BleeckerTheme.dark=false;BleeckerTheme.textScale=1;BleeckerTheme.reducedMotion=true;failOnWarning(/Binding loop|Cannot assign|TypeError/)}
        function cleanup(){BleeckerTheme.dark=false;BleeckerTheme.textScale=1}
        function settle(item){waitForPolish(item);wait(10)}
        function make(factory){const item=createTemporaryObject(factory,root);verify(item);settle(item);return item}
        function test_empty_and_zero_are_distinct(){
            const empty=make(emptyFactory),zero=make(zeroFactory)
            compare(empty.partCount,0);compare(empty.implicitWidth,0);compare(empty.implicitHeight,0)
            compare(zero.partCount,1);compare(zero.implicitWidth,36);compare(zero.implicitHeight,40)
        }
        function test_caller_identity_and_disabled_action(){
            const style=make(fixedFactory),label=style.labels[0],part=style.partAt(0)
            compare(style.implicitWidth,236);compare(style.implicitHeight,80)
            mouseClick(part.inputItem);compare(label.value,1)
            style.variant="secondary";style.size="sm";BleeckerTheme.dark=true;settle(style)
            compare(style.labels[0],label);compare(style.partAt(0),part);compare(part.labelItem,label)
            compare(style.implicitWidth,228);compare(style.implicitHeight,80)
            style.enabled=false;mouseClick(part.inputItem);compare(label.value,1);compare(part.presentationItem.opacity,0.45)
            style.enabled=true;mouseClick(part.inputItem);compare(label.value,2)
        }
        function test_font_and_foreground_inherit_but_inner_override_wins(){
            const style=make(fontFactory),label=style.labels[0],own=make(ownFontFactory),explicit=own.labels[0]
            compare(label.font.family,"Encode Sans");fuzzyCompare(label.font.pointSize,BleeckerFonts.pointSizeForPixels(14),0.000001)
            compare(label.color,style.foregroundColor)
            style.size="lg";BleeckerTheme.textScale=1.5;settle(style);settle(own)
            fuzzyCompare(label.font.pointSize,BleeckerFonts.pointSizeForPixels(22.5),0.000001)
            compare(explicit.font.family,"Libre Franklin");fuzzyCompare(explicit.font.pointSize,BleeckerFonts.pointSizeForPixels(13),0.000001)
            compare(explicit.font.weight,Font.Bold);verify(Qt.colorEqual(explicit.color,"red"))
        }
        function test_flat_parts_participate_in_parent_layout(){
            const owner=make(rowFactory),style=owner.style
            owner.row.layout();settle(owner.row)
            compare(style.partCount,2);compare(owner.row.implicitWidth,339.5);compare(owner.row.implicitHeight,44)
            const first=style.partAt(0),second=style.partAt(1)
            compare(first.width,128.5);compare(first.height,40);compare(first.x,51)
            compare(second.width,108);compare(second.height,44);compare(second.x,190.5)
        }
        function test_shared_pressed_visuals_and_cross_part_cancel(){
            const owner=make(rowFactory),style=owner.style
            owner.row.layout();settle(owner.row)
            const first=style.partAt(0),second=style.partAt(1)
            mousePress(first.inputItem);verify(style.down);compare(owner.calls,0)
            mouseRelease(first.inputItem);compare(owner.calls,1);verify(!style.down)
            mousePress(second.inputItem);verify(style.down);compare(owner.calls,1)
            mouseRelease(second.inputItem);compare(owner.calls,2);verify(!style.down)
            mousePress(first.inputItem)
            const end=second.inputItem.mapToItem(root,second.inputItem.width/2,second.inputItem.height/2)
            mouseMove(root,end.x,end.y);mouseRelease(root,end.x,end.y)
            compare(owner.calls,2);verify(!style.down)
        }
        function test_transparent_corner_input_survives_pressed_transform(){
            const style=make(fixedFactory),part=style.partAt(0),label=style.labels[0]
            mousePress(part.inputItem,0.5,0.5);verify(style.down);compare(label.value,0)
            mouseRelease(part.inputItem,0.5,0.5);compare(label.value,1)
        }
        function test_zero_offer_retains_decorated_body_and_input(){
            const style=make(fixedFactory);style.widthOffer=0;settle(style)
            const part=style.partAt(0)
            compare(style.width,0);compare(part.width,0);compare(part.presentationItem.width,236)
            compare(part.inputItem.width,236);compare(part.inputItem.x,-118)
        }
    }
}
