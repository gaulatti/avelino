#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Avelino::Avelino" for configuration "Release"
set_property(TARGET Avelino::Avelino APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Avelino::Avelino PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/qml/Avelino/libAvelino.so"
  IMPORTED_SONAME_RELEASE "libAvelino.so"
  )

list(APPEND _cmake_import_check_targets Avelino::Avelino )
list(APPEND _cmake_import_check_files_for_Avelino::Avelino "${_IMPORT_PREFIX}/lib/qml/Avelino/libAvelino.so" )

# Import target "Avelino::Avelinoplugin" for configuration "Release"
set_property(TARGET Avelino::Avelinoplugin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Avelino::Avelinoplugin PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/qml/Avelino/libAvelinoplugin.so"
  IMPORTED_NO_SONAME_RELEASE "TRUE"
  )

list(APPEND _cmake_import_check_targets Avelino::Avelinoplugin )
list(APPEND _cmake_import_check_files_for_Avelino::Avelinoplugin "${_IMPORT_PREFIX}/lib/qml/Avelino/libAvelinoplugin.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
