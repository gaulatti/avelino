
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was AvelinoConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
# Older CMake dependency configs can replace PACKAGE_PREFIX_DIR. Resolve our
# paths before loading Qt, using this package's own relocated installation root.
set_and_check(Avelino_QML_IMPORT_PATH "${PACKAGE_PREFIX_DIR}/lib/qml")
include(CMakeFindDependencyMacro)
find_dependency(Qt6 6.8.3 EXACT COMPONENTS Core Gui Qml Quick QuickControls2)
include("${CMAKE_CURRENT_LIST_DIR}/AvelinoTargets.cmake")
check_required_components(Avelino)
