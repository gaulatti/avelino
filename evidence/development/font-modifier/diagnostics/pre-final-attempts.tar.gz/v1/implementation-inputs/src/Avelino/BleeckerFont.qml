pragma FunctionSignatureBehavior: Enforced
import QtQuick

InheritedControl {
    id:scope
    default property list<Item> content
    required property string family
    required property real size
    property string weight:"regular"
    property real textScale:inheritedScale(parent)
    readonly property real bleeckerTextScale:textScale
    readonly property real requestedPixelSize:size*textScale
    readonly property real resolvedPixelSize:resolveSize()
    property real widthOffer:-1
    property real maximumWidth:-1
    property bool componentReady:false
    readonly property int partCount:parts.count
    readonly property bool containsTextBaseline:metrics.containsTextBaseline
    readonly property QtObject metrics:QtObject {
        property real width:0
        property real height:0
        property real baseline:0
        property bool containsTextBaseline:false
    }
    function inheritedScale(ancestor:Item):real {
        let current=ancestor
        while(current){
            if(typeof current.bleeckerTextScale==="number")return current.bleeckerTextScale
            current=current.parent
        }
        return BleeckerTheme.textScale
    }
    function resolveSize():real {
        const value=requestedPixelSize
        if(!Number.isFinite(value))throw new Error("BleeckerFont size and text scale must produce a finite size")
        if(value<=0)return 12
        return family==="mono" ? value:Math.round(value)||12
    }
    function resolveFamily():string {
        switch(family){
        case "primary":return BleeckerFonts.primary
        case "secondary":return BleeckerFonts.secondary
        case "mono":return BleeckerFonts.monospace
        default:throw new Error("Unknown Bleecker font family: "+family)
        }
    }
    function resolveWeight():int {
        const values={ultraLight:Font.Thin,thin:Font.ExtraLight,light:Font.Light,regular:Font.Normal,
            medium:Font.Medium,semibold:Font.DemiBold,bold:Font.Bold,heavy:Font.ExtraBold,black:Font.Black}
        if(values[weight]===undefined)throw new Error("Unknown Bleecker font weight: "+weight)
        if(family==="mono" && ["ultraLight","thin"].includes(weight))return Font.Light
        if(family==="mono" && weight==="black")return Font.ExtraBold
        return values[weight]
    }
    function partAt(index:int):Item {return parts.itemAt(index)}
    function refreshGeometry():void {
        if(!parts)return
        let width=0,height=0,baseline=0,hasBaseline=false
        for(let index=0;index<parts.count;++index){
            const part=parts.itemAt(index)
            if(part){width=Math.max(width,part.implicitWidth);height=Math.max(height,part.implicitHeight)}
        }
        for(let index=0;index<parts.count;++index){
            const part=parts.itemAt(index)
            if(part && part.containsTextBaseline){
                const value=(height-part.implicitHeight)/2+part.baselineOffset
                baseline=hasBaseline ? Math.min(baseline,value):value;hasBaseline=true
            }
        }
        metrics.width=width;metrics.height=height;metrics.baseline=hasBaseline ? baseline:height
        metrics.containsTextBaseline=hasBaseline
    }
    function validate():void {
        resolveFamily();resolveWeight();resolveSize()
        if(!Number.isFinite(size)||!Number.isFinite(textScale))throw new Error("BleeckerFont size and text scale must be finite")
        for(const value of [widthOffer,maximumWidth])
            if(!Number.isFinite(value)||(value<0 && value!==-1))throw new Error("BleeckerFont width proposals must be nonnegative or -1")
    }
    padding:0;background:null;contentItem:null;focusPolicy:Qt.NoFocus;hoverEnabled:false;wheelEnabled:false
    font.family:resolveFamily()
    font.pointSize:BleeckerFonts.pointSizeForPixels(resolvedPixelSize)
    font.weight:resolveWeight()
    implicitWidth:metrics.width;implicitHeight:metrics.height;baselineOffset:metrics.baseline
    BleeckerLayout.flattenChildren:true
    BleeckerLayout.firstBaseline:containsTextBaseline ? baselineOffset:NaN
    Accessible.ignored:true
    Component.onCompleted:{componentReady=true;validate()}
    onFamilyChanged:if(componentReady)validate()
    onWeightChanged:if(componentReady)validate()
    onSizeChanged:if(componentReady)validate()
    onTextScaleChanged:if(componentReady)validate()
    onWidthOfferChanged:if(componentReady)validate()
    onMaximumWidthChanged:if(componentReady)validate()
    readonly property Repeater parts:Repeater {
        parent:scope;model:scope.content
        delegate:FontPart {required property Item modelData;caller:modelData;fontScope:scope}
        onItemAdded:scope.refreshGeometry()
        onItemRemoved:scope.refreshGeometry()
    }
}
