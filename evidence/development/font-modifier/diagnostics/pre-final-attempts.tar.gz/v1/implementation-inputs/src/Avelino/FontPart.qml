pragma FunctionSignatureBehavior: Enforced
import QtQuick

Item {
    id:part
    required property Item caller
    required property var fontScope
    readonly property real parentOffer:BleeckerLayout.proposedWidth
    readonly property real effectiveOffer:fontScope.widthOffer>=0 ? fontScope.widthOffer
        :fontScope.maximumWidth<0 ? parentOffer:parentOffer<0 ? fontScope.maximumWidth:Math.min(parentOffer,fontScope.maximumWidth)
    readonly property bool containsTextBaseline:layout.containsTextBaseline
    readonly property Item callerLayout:layout
    BleeckerLayout.minimumWidth:fontScope.widthOffer>=0 ? fontScope.widthOffer:layout.minimumWidth
    BleeckerLayout.idealWidth:fontScope.widthOffer>=0 ? fontScope.widthOffer:layout.naturalWidth
    BleeckerLayout.firstBaseline:containsTextBaseline ? baselineOffset:NaN
    implicitWidth:fontScope.widthOffer>=0 ? fontScope.widthOffer:layout.implicitWidth
    implicitHeight:layout.implicitHeight
    baselineOffset:layout.baselineOffset
    x:(fontScope.width-width)/2;y:(fontScope.height-height)/2
    function attach():void {if(caller && host)caller.parent=host}
    Component.onCompleted:attach()
    Component.onDestruction:if(caller && caller.parent===host)caller.parent=null
    onCallerChanged:attach()
    onImplicitWidthChanged:if(fontScope)fontScope.refreshGeometry()
    onImplicitHeightChanged:if(fontScope)fontScope.refreshGeometry()
    onBaselineOffsetChanged:if(fontScope)fontScope.refreshGeometry()
    onContainsTextBaselineChanged:if(fontScope)fontScope.refreshGeometry()
    ProposalRow {
        id:layout
        x:(part.width-width)/2;y:0
        maximumWidth:part.effectiveOffer
        mirrored:part.fontScope.mirrored;spacing:0
        Item {id:host;BleeckerLayout.flattenChildren:true}
    }
}
